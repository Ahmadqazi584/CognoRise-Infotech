import java.util.Random;
import java.util.Scanner;

    public class Main {
    public static void main(String[] args) {
        Random random = new Random();
        Scanner scanner = new Scanner(System.in);

        // Generate a random number between 1 and 100
        int numberToGuess = random.nextInt(100) + 1;
        int numberOfAttempts = 0;
        int userGuess = 0;
        final int maxAttempts = 5;  // Maximum attempts allowed

        System.out.println("Guess the number (between 1 and 100). You have " + maxAttempts + " attempts:");

        // Game loop
        while (userGuess != numberToGuess && numberOfAttempts < maxAttempts) {
            try {
                System.out.print("Enter your guess: ");
                userGuess = scanner.nextInt();  // Read user input

                numberOfAttempts++;  // Increment number of attempts

                // Provide feedback
                if (userGuess < numberToGuess) {
                    System.out.println("Your guess is too low.");
                } else if (userGuess > numberToGuess) {
                    System.out.println("Your guess is too high.");
                } else {
                    System.out.println("Congratulations! You guessed the number in " + numberOfAttempts + " attempts.");
                }
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a valid integer number.");
                scanner.next();  // Consume the invalid input
            }
        }

        if (userGuess != numberToGuess) {
            System.out.println("Game over! The number was: " + numberToGuess);
        }

        scanner.close();
    }
}
