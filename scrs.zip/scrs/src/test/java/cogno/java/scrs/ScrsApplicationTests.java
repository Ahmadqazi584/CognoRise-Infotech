package cogno.java.scrs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScrsApplicationTests {

	@Test
	void contextLoads() {
	}

}
