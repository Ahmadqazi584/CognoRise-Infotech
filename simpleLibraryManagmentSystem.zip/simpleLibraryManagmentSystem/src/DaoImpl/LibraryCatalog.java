package DaoImpl;

import model.Book;

import java.util.ArrayList;

public class LibraryCatalog {
    ArrayList<Book> booklist;

    public LibraryCatalog() {
        booklist = new ArrayList<Book>();

        // Adding some default books
        booklist.add(new Book("To Kill a Mockingbird", "Harper Lee", true));
        booklist.add(new Book("1984", "George Orwell", false));
        booklist.add(new Book("The Great Gatsby", "F. Scott Fitzgerald", true));
        booklist.add(new Book("Pride and Prejudice", "Jane Austen", false));
        booklist.add(new Book("Catcher in the Rye", "J.D. Salinger", true));
    }

    public void addBook(String title, String author, Boolean status){
        booklist.add(new Book(title, author, status));
    }

    public Book searchBook(int choice, String text){
        // search by title
        if(choice == 1){
            for (Book b : booklist){

                if(text.equals(b.getTitle())){
                    return b;
                }
            }
        }
        // search by author
        if(choice == 2){
            for (Book b : booklist){
                if(text.equals(b.getAuthor())){
                    return b;
                }
            }
        }
        return null;
    }

    public Boolean checkoutBook(int choice, String text){
        Book book = searchBook(choice, text);
        if(book != null && book.isStatus()){
            book.setStatus(false);
            return true;
        }
        return false;
    }

    public Boolean returnBook(int choice, String text){
        Book book = searchBook(choice, text);
        if (book != null && !book.isStatus()) {
            book.setStatus(true);
            return true;
        }
        return false;
    }

    public void displayBooks() {
        for (Book b : booklist) {
            System.out.println(b);
        }
    }
}
