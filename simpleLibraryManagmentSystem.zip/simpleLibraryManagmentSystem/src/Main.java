import ServiceImpl.LibraryCatalogService;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        LibraryCatalogService lcs = new LibraryCatalogService();
        lcs.lmsApp();
    }
}