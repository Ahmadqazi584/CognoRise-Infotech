package ServiceImpl;

import DaoImpl.LibraryCatalog;
import model.Book;

import java.util.Scanner;

public class LibraryCatalogService {
    Scanner sc = new Scanner(System.in);
    LibraryCatalog libraryCatalog = new LibraryCatalog();
    String title;
    String author;
    String text;
    byte choice;
    char ch;

    public void lmsHeader(){
        System.out.println("------------------------------------------------");
        System.out.println("===== Welcome to Library Management System =====");
        System.out.println("------------------------------------------------");
        System.out.println();
    }
    public void lmsMenu(){
        System.out.println("1. Add Book");
        System.out.println("2. Search Book By Title or Author");
        System.out.println("3. Book Checkout");
        System.out.println("4. Book Return");
        System.out.println("5. Display All Books");
    }
    public void lmsBody(int menuitem){
        if(menuitem == 1){
            System.out.print("Enter the title: ");
            title = sc.nextLine();
            System.out.print("Enter the author: ");
            author = sc.nextLine();
            libraryCatalog.addBook(title, author, true);
            libraryCatalog.displayBooks();
        }else if (menuitem == 2){
            System.out.println("Enter choice: ");
            System.out.println("1. title");
            System.out.println("2. author");
            choice = sc.nextByte();
            sc.nextLine();
            System.out.print("Enter title or author: ");
            text = sc.nextLine();

            Book book = libraryCatalog.searchBook(choice, text);
            if(book != null){
                if(book.isStatus()==true){
                    System.out.println(book.getTitle() + " " + book.getAuthor() + " available");
                }else {
                    System.out.println(book.getTitle() + " " + book.getAuthor() + " checked out");
                }
            }else {
                System.out.println("Book not found!");
            }
        }else if(menuitem == 3){
            System.out.println("Enter choice: ");
            System.out.println("1. title");
            System.out.println("2. author");
            choice = sc.nextByte();
            sc.nextLine();
            System.out.print("Enter title or author: ");
            text = sc.nextLine();

            Book book = libraryCatalog.searchBook(choice, text);
            if(book != null){
                if (book.isStatus() == true){
                    System.out.println(book.getTitle() + " " + book.getAuthor() + " available");
                    System.out.print("Do you want to checkout? (y/n) :");
                    ch = sc.next().charAt(0);
                    if(ch == 'y'){
                        book.setStatus(false);
                        System.out.println("book checked out successfully");
                    }
                    if (ch == 'n'){
                        System.out.println("book checked out unsuccessfully");
                    }
                }
            }
        }else if(menuitem == 4) {
            System.out.println("Enter choice: ");
            System.out.println("1. title");
            System.out.println("2. author");
            choice = sc.nextByte();
            sc.nextLine();
            System.out.print("Enter title or author: ");
            text = sc.nextLine();

            Book book = libraryCatalog.searchBook(choice, text);
            if (book != null) {
                if (book.isStatus() == false) {
                    System.out.println(book.getTitle() + " " + book.getAuthor() + " checked out");
                    System.out.print("Do you want to return? (y/n) :");
                    ch = sc.next().charAt(0);
                    if (ch == 'y') {
                        book.setStatus(true);
                        System.out.println("book returned successfully");
                    }
                    if (ch == 'n') {
                        System.out.println("book returned unsuccessfully");
                    }
                }
            }
        }else if (menuitem == 5){
            libraryCatalog.displayBooks();
        }
    }

    public void lmsApp(){
        Scanner input = new Scanner(System.in);
        int menuitem;
        lmsHeader();
        lmsMenu();
        System.out.println("Enter the menu item: ");
        menuitem = input.nextInt();
        lmsBody(menuitem);
    }
}
